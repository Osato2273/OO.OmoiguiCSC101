CREATE DATABASE  IF NOT EXISTS `staffinfo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `staffinfo`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: staffinfo
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `idSales` int NOT NULL AUTO_INCREMENT,
  `productname` varchar(45) NOT NULL,
  `quantitysold` int NOT NULL,
  `dateofsale` date NOT NULL,
  `cashiername` varchar(45) NOT NULL,
  `valueofsale` int NOT NULL,
  PRIMARY KEY (`idSales`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (43,'Wild-caught Salmon Fillet',4,'2024-02-04','',249400),(44,'Grass-fed Beef Steak',10,'2024-02-04','Nifemi Ipaye',2026375),(45,'Extra Virgin Olive Oil 500ml',5,'2024-02-04','Nifemi Ipaye',4031),(46,'Cway Water',5,'2024-02-04','Nifemi Ipaye',4031),(47,'Organic Blueberries',6,'2024-02-04','Jumoke Bamigbade',729495),(48,'Grass-fed Beef Steak',6,'2024-02-04','Jumoke Bamigbade',729495),(49,'Organic Avocado',8,'2024-02-10','Adaobi Arinzechi',34400);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staffid` int NOT NULL AUTO_INCREMENT,
  `staffname` varchar(45) NOT NULL,
  `dateofbirth` date NOT NULL,
  `phonenumber` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `passport` blob NOT NULL,
  `role` varchar(45) NOT NULL,
  PRIMARY KEY (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (12,'Munachi Anya','2024-01-03','09011718329','Male','munachianya@gmail.com','d8578edf8458ce06fbc5bb76a58c5ca4',_binary 'jTextField6','IT Manager'),(13,'Nifemi Ipaye','2004-02-09','09078657688','Male','nifiroze2005@gmail.com','926244c50c54073e36f02bf4c9e46c38',_binary 'jTextField6','Cashier'),(14,'Osato Omoigui','2004-01-01','09030435677','Female','foodlover2273@gmail.com','6b13050da45d76557aee183f9096fb55','','Inventory Manager'),(15,'Mobolaji Pedro','2002-08-01','09087655567','Male','hamzyy3@gmail.com','4985bc3c516483ada003c63f5a03a6bc','','Cashier'),(16,'Sophia Pedro','2002-02-07','07065779809','Female','osatohanmwen.omoigui@pau.edu.ng','b73c2d22763d1ce2143a3755c1d0ad3a','','Sales Manager'),(17,'Jumoke Bamigbade','2006-05-08','08077665544','Female','jumoke.1bamigbade@gmail.com','7e5b9cd4138da00c1ce110ee1d2ff888','','Cashier'),(18,'Adaobi Arinzechi','2004-04-05','090567899','Female','adaobi.arinzechi@pau.edu.ng','ef56d54fb651d81bfd1b960151a953f6',_binary 'jTextField6','Cashier'),(19,'Lola Shaibu','2004-02-11','09087665566','Male','foodlover2273@gmail.com','d8578edf8458ce06fbc5bb76a58c5ca4',_binary 'jTextField6','Cashier');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `idinventory` int NOT NULL AUTO_INCREMENT,
  `productname` varchar(45) NOT NULL,
  `productcode` varchar(45) NOT NULL,
  `manufacturer` varchar(45) NOT NULL,
  `manufacturingdate` varchar(45) NOT NULL,
  `expirydate` varchar(45) NOT NULL,
  `productprice` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `quantity` varchar(45) NOT NULL,
  PRIMARY KEY (`idinventory`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (1,'Power Oil 2L','PWROILDUF2L','Dufil Prima Foods Plc.','2023-02-01','2024-02-08','7800','2024-02-03','180'),(2,'Blue Band 250g','BLUBANUP250G','Upfield Ghana Manufacturing Ltd.','2023-01-01','2024-02-29','650','2024-02-03','500'),(3,'Cway Water','CWAYDRIWA750ML','Cway Nigeria Drinking Water','2023-12-01','2024-12-09','150','2024-02-03','445'),(6,'Organic Avocado','AV001',' Fresh Farms Co.','2024-02-02','2024-07-23','500','2024-02-03','91'),(7,'Grass-fed Beef Steak','BS002','Pasture Prime Meats','2023-05-03','2025-12-31','18850','2024-02-03','12'),(8,'Organic Kale','KL003','Green Harvest Organics','2023-01-01','2024-02-24','2175','2023-02-02','15'),(9,'Wild-caught Salmon Fillet','SF004','Ocean Bounty Fisheries','2023-12-22','2024-02-29','14500','2024-01-03','20'),(10,'Organic Blueberries','BB006','Berry Bliss Farms','2024-01-01','2024-12-01','5800','2024-02-03','94'),(11,'Extra Virgin Olive Oil 500ml','OO010','Olive Grove Estates','2024-01-31','2026-02-13','6800','2024-02-03','445');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'staffinfo'
--

--
-- Dumping routines for database 'staffinfo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-10 21:45:36
